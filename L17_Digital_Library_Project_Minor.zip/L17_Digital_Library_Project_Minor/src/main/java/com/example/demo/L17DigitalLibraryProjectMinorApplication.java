package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L17DigitalLibraryProjectMinorApplication {

	public static void main(String[] args) {
		SpringApplication.run(L17DigitalLibraryProjectMinorApplication.class, args);
	}

}
