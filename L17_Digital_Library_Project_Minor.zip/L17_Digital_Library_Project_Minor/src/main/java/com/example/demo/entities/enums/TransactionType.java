package com.example.demo.entities.enums;

public enum TransactionType {

	ISSUE,RETURN

}