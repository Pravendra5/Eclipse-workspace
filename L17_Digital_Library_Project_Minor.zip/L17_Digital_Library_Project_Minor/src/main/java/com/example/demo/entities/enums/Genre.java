package com.example.demo.entities.enums;

public enum Genre {
	
	FICTION,NON_FICTION,TECHNICAL

}