package com.example.demo.entities.enums;

public enum TransactionStatus {

	PENDING,SUCCESS,FAILED
}