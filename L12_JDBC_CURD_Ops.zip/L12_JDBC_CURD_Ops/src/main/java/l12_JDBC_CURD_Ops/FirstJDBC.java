package l12_JDBC_CURD_Ops;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JFileChooser;

import java.sql.SQLException;
import java.io.*;

public class FirstJDBC {
	
	public static void main(String args[]) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			
			String url = "jdbc:mysql://localhost:3306/Youtube";
			String username =  "root";
			String password = "Pravendra@123";
			
			Connection con = DriverManager.getConnection(url,username,password);
			
			//createTable(con);
			//insertRecord(con);
			//insertRecordDPS(con,3,"Nidheesh", "Dangi", 23);
			//insertUserRecordDPS(con);
			//updateRecordPS(con, "Hello", 53);
			//deleteRecordPS(con, 53);
			//uploadFile(con);
			//selectQuery(con);
			updateRecordPSwithRS(con);
			
			
			}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static void createTable(Connection con)  throws SQLException {
		String query = "CREATE TABLE IF NOT EXISTS registeration"
				+ "(eId int(20) NOT NULL primary key auto_increment,"
				+ "first VARCHAR(45) NOT NULL,"
				+ "last VARCHAR(45) NOT NULL,"
				+ "age VARCHAR(45) NOT NULL)";
				
			Statement stmt = con.createStatement();
			stmt.executeUpdate(query);
			
			System.out.println("Table Created");
			
			con.close();
	}
	public static int insertRecord(Connection con) throws SQLException {
		String q = "INSERT INTO registeration values(1, 'Pravendra', 'Dangi', 22);";
		Statement stmt = con.createStatement();
		int result = stmt.executeUpdate(q);
		System.out.println("Inserted result" + result);
		return result;
		
	}
	public static int insertRecordDPS(Connection con, int eId, String first,String last, int age) throws SQLException {
		String q = "INSERT INTO registeration VALUES(?,?,?,?);";
		PreparedStatement pstmt = con.prepareStatement(q);
		
		pstmt.setInt(1, eId);
		pstmt.setString(2, first);
		pstmt.setString(3, last);
		pstmt.setInt(4, age);
		
		int result = pstmt.executeUpdate();
		System.out.println("Insertion Result : "+result);
		return result;
		
		}
	public static void insertUserRecordDPS(Connection con) throws SQLException, IOException {
		String q = "INSERT INTO registeration VALUES(?,?,?,?);";
		PreparedStatement pstmt = con.prepareStatement(q);
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Insert your ID: ");
		int id = br.read();
		System.out.println("Insert your firstname: ");
		String first = br.readLine();
		System.out.println("Insert your lastname: ");
		String last = br.readLine();
		System.out.println("Insert your age: ");
		int age = br.read();
		
		
		pstmt.setInt(1, id);
		pstmt.setString(2, first);
		pstmt.setString(3, last);
		pstmt.setInt(4, age);
		
		int result = pstmt.executeUpdate();
		System.out.println("Insertion Result : "+result);
		
}
	public static int updateRecordPS(Connection con, String first, int eId) throws SQLException {
		String sql = "Update registeration set first = ? where eId = ?;";
		
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		pstmt.setString(1, first);
		pstmt.setInt(2, eId);
	
		
		
		int result = pstmt.executeUpdate();
		
		System.out.println("Insertion Result : "+result);
		return result;
		
	}
	public static int deleteRecordPS(Connection con,int eId) throws SQLException {
		String sql = "delete from `registeration` where eId = ?;";
		
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		pstmt.setInt(1, eId);
		
		int result = pstmt.executeUpdate();
		
		System.out.println("Deletion Result : "+result);
		return result;
		
	}
	public static void uploadFile(Connection con) throws SQLException, IOException {
	String q = "insert into image(pic) values(?);";
	
	PreparedStatement pstmt = con.prepareStatement(q);
	
	JFileChooser jfc = new JFileChooser();
	
	jfc.showOpenDialog(null);
	
	File file = jfc.getSelectedFile();
	
	FileInputStream fis = new FileInputStream(file);
	
	pstmt.setBinaryStream(1, fis, fis.available());
	
	pstmt.executeUpdate();
	
	System.out.println("Done");
}
	public static void selectQuery(Connection con) throws SQLException {
	 String sql = "Select * from registeration;";
	 Statement stmt = con.createStatement();
	 ResultSet set = stmt.executeQuery(sql);
	 System.out.println(set.getRow());
	 System.out.println("ID        First Name      Last Name     Age ");
	 
	 while(set.next()) {
		 System.out.println(set.getInt(1)+"          "+set.getString(2)+"      "+set.getString(3)+"          "+set.getInt(4));
	 }
	}
	public static void updateRecordPSwithRS(Connection con) throws SQLException {
		String sql = "Update `registeration`set age = ? where eId = ?;";
		
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		pstmt.setInt(1, 50);
		pstmt.setInt(2, 2);
		
		int result = pstmt.executeUpdate();
		
		System.out.println("Insertion Result : "+result);
		
		String sql2 = "select * from `registeration` where eId=2;";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql2);
		System.out.println(rs.getRow());
		System.out.println("*****************************************************");
		System.out.println("ID            First Name      Last Name          Age ");
	
		
		while(rs.next()) {
			System.out.println(rs.getInt(1)+"            "+rs.getString(2)+"      "+rs.getString(3)+"          "+rs.getInt(4) );
			
		}
		
		
		System.out.println("*****************************************************");
		
		rs.close();
		stmt.close();
		
	
	}
}
