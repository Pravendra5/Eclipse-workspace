package com.example.demo;

import java.io.*;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.*;

public class ExcelReader {
    public static void main(String[] args) {
        String filePath = "C:\\Users\\My Computers\\Desktop\\Employee.xlsx";
        try (FileInputStream file = new FileInputStream(new File(filePath));
             Workbook workbook = WorkbookFactory.create(file)) {

            Sheet sheet = workbook.getSheetAt(0);
            StringBuilder mergedData = new StringBuilder();
            
            for (Row row : sheet) {
                Cell nameCell = row.getCell(0);
                Cell ageCell = row.getCell(1);
                Cell heightCell = row.getCell(2);

                mergedData.append(getStringValue(nameCell))
                          .append(getStringValue(ageCell))
                          .append(getStringValue(heightCell))
                          .append("\n");
            }

            System.out.println(mergedData.toString());
        } catch (IOException | EncryptedDocumentException ex) {
            ex.printStackTrace();
        }
    }

    private static String getStringValue(Cell cell) {
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    // Check if the cell contains an integer value
                    if (cell.getNumericCellValue() % 1 == 0) {
                        // If it's an integer, return it as an integer
                        return String.valueOf((int) cell.getNumericCellValue());
                    } else {
                        // If it's a decimal, return it as a decimal
                        return String.valueOf(cell.getNumericCellValue());
                    }
                }
            // Handle other cell types as needed
                
            default:
                return "";
        }
    }
}
